NAIJA LIFE 3D — MULTIPLAYER PROTOTYPE 0.2

FILES
- index.html: browser game with optional multiplayer connection fields
- server.js: WebSocket room server; relays player movement between people in the same room
- package.json: Node.js dependencies and start command

IMPORTANT
This is an early multiplayer prototype. It shares room membership and avatar movement only. It does NOT yet have secure accounts, server-validated money/jobs, persistent online saves, moderation, or production anti-cheat. Do not treat browser-side money as secure.

RUN THE SERVER LOCALLY
1. Install Node.js 18 or newer on a computer.
2. Open a terminal in this folder.
3. Run: npm install
4. Run: npm start
5. The health endpoint is http://localhost:8080/health
6. For testing on the same computer, set the game's server URL to ws://localhost:8080.
   For a phone on the same Wi-Fi, use ws://COMPUTER_LOCAL_IP:8080 and allow the port through the computer firewall.

DEPLOY FOR INTERNET MULTIPLAYER (LOW-COST APPROACH)
1. Create a GitHub repository and upload index.html, server.js, package.json, and this README.
2. Create a Node.js web service on a host that supports WebSockets (for example, Render or another compatible host).
3. Set the build/install command to: npm install
4. Set the start command to: npm start
5. Deploy, then check the service's /health page. It should return JSON with status "ok".
6. Copy the service's public URL into the game. Use wss:// instead of https://, for example:
   https://your-service.example -> wss://your-service.example
7. Host index.html over HTTPS (a static host such as GitHub Pages can work), open it on two devices, enter the same server URL and room code (for example LAGOS), and tap CONNECT MULTIPLAYER on both devices.
8. Tap ENTER THE NEIGHBOURHOOD on both devices. Walk around; the other player's avatar should follow.

COST NOTE
Start on a free tier if one is currently available. Free hosting rules and sleep limits can change; a sleeping server may take time to wake up. Do not pay for hosting until the two-device test works and you know you need an always-on server.

SECURITY / NEXT STEPS
- Add authenticated identities and server-authoritative game state before real money, trading, purchases, or valuable saved progress.
- Add chat UI, message moderation, reconnect handling, room cleanup, monitoring, and abuse protection before public launch.
- Keep secrets and payment credentials off the browser client.
