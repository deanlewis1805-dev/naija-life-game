'use strict';
// Naija Life 3D: small WebSocket room server prototype.
// Run with Node.js 18+: npm install && npm start
const http = require('http');
const { WebSocketServer, WebSocket } = require('ws');
const PORT = Number(process.env.PORT || 8080);
const server = http.createServer((req, res) => {
  if (req.url === '/health' || req.url === '/') {
    res.writeHead(200, { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store' });
    res.end(JSON.stringify({ game: 'Naija Life 3D Multiplayer', status: 'ok', protocol: 'websocket' }));
    return;
  }
  res.writeHead(404, { 'content-type': 'text/plain; charset=utf-8' });
  res.end('Not found');
});
const wss = new WebSocketServer({ server, maxPayload: 2048 });
const rooms = new Map();
const COLORS = ['#24a18a', '#5d91b2', '#b64c3d', '#d28bba', '#7e9e4e', '#c99a32'];
function safeSend(ws, payload) {
  if (ws.readyState === WebSocket.OPEN) ws.send(JSON.stringify(payload));
}
function cleanRoom(value) {
  return String(value || 'LAGOS').toUpperCase().replace(/[^A-Z0-9-]/g, '').slice(0, 16) || 'LAGOS';
}
function cleanName(value) {
  return String(value || 'Player').replace(/[<>\u0000-\u001f]/g, '').trim().slice(0, 18) || 'Player';
}
function publicPlayer(p) {
  return { id: p.id, name: p.name, x: p.x, z: p.z, rotation: p.rotation, color: p.color };
}
function broadcast(room, payload, exceptId) {
  for (const p of room.players.values()) {
    if (p.id !== exceptId) safeSend(p.ws, payload);
  }
}
wss.on('connection', (ws) => {
  const p = { ws, id: Math.random().toString(36).slice(2, 10), name: 'Player', roomCode: null, x: 0, z: 5, rotation: 0, color: COLORS[Math.floor(Math.random() * COLORS.length)], lastMove: 0 };
  ws.on('message', (raw) => {
    let msg;
    try { msg = JSON.parse(raw.toString()); } catch { return; }
    if (!msg || typeof msg.type !== 'string') return;
    if (msg.type === 'join') {
      if (p.roomCode) return;
      const code = cleanRoom(msg.room);
      let room = rooms.get(code);
      if (!room) { room = { players: new Map() }; rooms.set(code, room); }
      if (room.players.size >= 32) { safeSend(ws, { type: 'error', message: 'This room is full (32 players).' }); return; }
      p.roomCode = code;
      p.name = cleanName(msg.name);
      room.players.set(p.id, p);
      safeSend(ws, { type: 'welcome', id: p.id, room: code, players: [...room.players.values()].filter(other => other.id !== p.id).map(publicPlayer), self: publicPlayer(p) });
      broadcast(room, { type: 'playerJoined', player: publicPlayer(p) }, p.id);
      return;
    }
    if (!p.roomCode) return;
    const room = rooms.get(p.roomCode);
    if (!room) return;
    if (msg.type === 'move') {
      const now = Date.now();
      if (now - p.lastMove < 40) return; // max 25 movement updates/sec/player
      p.lastMove = now;
      const x = Number(msg.x), z = Number(msg.z), rotation = Number(msg.rotation);
      if (![x, z, rotation].every(Number.isFinite)) return;
      p.x = Math.max(-48, Math.min(48, x));
      p.z = Math.max(-48, Math.min(48, z));
      p.rotation = Math.max(-Math.PI * 2, Math.min(Math.PI * 2, rotation));
      broadcast(room, { type: 'move', player: publicPlayer(p) }, p.id);
    } else if (msg.type === 'chat') {
      const text = String(msg.text || '').replace(/[<>\u0000-\u001f]/g, '').trim().slice(0, 160);
      if (text) broadcast(room, { type: 'chat', id: p.id, name: p.name, text, at: Date.now() });
    }
  });
  ws.on('close', () => {
    if (!p.roomCode) return;
    const room = rooms.get(p.roomCode);
    if (!room) return;
    room.players.delete(p.id);
    broadcast(room, { type: 'playerLeft', id: p.id });
    if (room.players.size === 0) rooms.delete(p.roomCode);
  });
});
server.listen(PORT, '0.0.0.0', () => console.log(`Naija Life 3D multiplayer server listening on port ${PORT}`));
